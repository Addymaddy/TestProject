package din2;

public interface Barrier
{
	public void arriveAndWait();
}
